#!/bin/bash
# ============================================================
# Train ViT Violence Classifier on UCF-Crime Dataset
# ============================================================
# Paper: "A Generalizable Vision Transformer Framework for
#         Low-False-Alarm Violence Detection"
#
# Expected dataset structure:
#   data/UCF_Crime/
#   ├── Normal/   (*.mp4 or *.avi)
#   ├── Abuse/
#   ├── Arrest/
#   ├── Assault/
#   ├── Burglary/
#   ├── Explosion/
#   ├── Fighting/
#   ├── RoadAccidents/
#   ├── Robbery/
#   ├── Shooting/
#   ├── Shoplifting/
#   ├── Stealing/
#   ├── Vandalism/
#   └── Arson/
# ============================================================

set -e

echo "============================================"
echo "  Training ViT on UCF-Crime Dataset"
echo "============================================"

python main.py \
    --mode train \
    --config configs/ucf_crime.yaml

echo ""
echo "Training complete!"
echo "Checkpoints: outputs/checkpoints/ucf/"
echo "Logs:        outputs/logs/ucf/"

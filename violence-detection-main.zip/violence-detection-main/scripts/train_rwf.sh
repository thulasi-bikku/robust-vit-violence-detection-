#!/bin/bash
# ============================================================
# Train ViT Violence Classifier on RWF-2000 Dataset
# ============================================================
# Paper: "A Generalizable Vision Transformer Framework for
#         Low-False-Alarm Violence Detection"
#
# Expected dataset structure:
#   data/RWF-2000/
#   ├── train/
#   │   ├── Fight/    (*.avi)
#   │   └── NonFight/ (*.avi)
#   └── val/
#       ├── Fight/    (*.avi)
#       └── NonFight/ (*.avi)
# ============================================================

set -e

echo "============================================"
echo "  Training ViT on RWF-2000 Dataset"
echo "============================================"

python main.py \
    --mode train \
    --config configs/rwf2000.yaml

echo ""
echo "Training complete!"
echo "Checkpoints: outputs/checkpoints/rwf/"
echo "Logs:        outputs/logs/rwf/"

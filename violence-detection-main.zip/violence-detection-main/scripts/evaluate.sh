#!/bin/bash
# ============================================================
# Evaluate a trained ViT Violence Detection checkpoint
# ============================================================
# Usage:
#   bash scripts/evaluate.sh <config_path> <checkpoint_path>
#
# Examples:
#   bash scripts/evaluate.sh configs/ucf_crime.yaml outputs/checkpoints/ucf/best_model.pth
#   bash scripts/evaluate.sh configs/rwf2000.yaml outputs/checkpoints/rwf/best_model.pth
# ============================================================

set -e

CONFIG=${1:-"configs/ucf_crime.yaml"}
CHECKPOINT=${2:-"outputs/checkpoints/ucf/best_model.pth"}

echo "============================================"
echo "  Evaluating Violence Detection Model"
echo "============================================"
echo "  Config    : ${CONFIG}"
echo "  Checkpoint: ${CHECKPOINT}"
echo "============================================"

# Run evaluation
python main.py \
    --mode evaluate \
    --config "${CONFIG}" \
    --checkpoint "${CHECKPOINT}"

echo ""

# Also generate Grad-CAM visualizations
echo "Generating Grad-CAM visualizations..."
python main.py \
    --mode visualize \
    --config "${CONFIG}" \
    --checkpoint "${CHECKPOINT}"

echo ""
echo "Evaluation complete!"

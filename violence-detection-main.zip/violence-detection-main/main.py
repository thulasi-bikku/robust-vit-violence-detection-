"""
Main CLI entry point for the Violence Detection ViT framework.

Supports three modes of operation:
  - train    : Train the ViT model on UCF-Crime or RWF-2000
  - evaluate : Evaluate a trained checkpoint on the test set
  - visualize: Generate Grad-CAM visualizations from a checkpoint

Usage:
  python main.py --mode train --config configs/ucf_crime.yaml
  python main.py --mode evaluate --config configs/ucf_crime.yaml --checkpoint outputs/checkpoints/ucf/best_model.pth
  python main.py --mode visualize --config configs/ucf_crime.yaml --checkpoint outputs/checkpoints/ucf/best_model.pth
"""

import argparse
import os
import sys
import time
from typing import Dict, Any

import torch

from src.dataset import UCFCrimeDataset, RWF2000Dataset, get_dataloader
from src.evaluate import Evaluator
from src.gradcam import VitGradCAM
from src.model import get_model
from src.train import Trainer
from src.transforms import get_train_transforms, get_val_test_transforms
from src.utils import (
    count_parameters,
    create_output_dirs,
    format_time,
    get_device,
    load_config,
    plot_training_history,
    save_metrics_to_csv,
    set_seed,
)


def parse_args() -> argparse.Namespace:
    """Parse command line arguments.

    Returns:
        Parsed argument namespace with mode, config, checkpoint,
        data_root, and device fields.
    """
    parser = argparse.ArgumentParser(
        description="Violence Detection using Vision Transformer (ViT)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Train on UCF-Crime:
    python main.py --mode train --config configs/ucf_crime.yaml

  Train on RWF-2000:
    python main.py --mode train --config configs/rwf2000.yaml

  Evaluate a checkpoint:
    python main.py --mode evaluate --config configs/ucf_crime.yaml \\
                   --checkpoint outputs/checkpoints/ucf/best_model.pth

  Generate Grad-CAM visualizations:
    python main.py --mode visualize --config configs/ucf_crime.yaml \\
                   --checkpoint outputs/checkpoints/ucf/best_model.pth
        """,
    )

    parser.add_argument(
        "--mode",
        type=str,
        required=True,
        choices=["train", "evaluate", "visualize"],
        help="Operation mode: train, evaluate, or visualize",
    )
    parser.add_argument(
        "--config",
        type=str,
        required=True,
        help="Path to YAML configuration file (e.g., configs/ucf_crime.yaml)",
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to model checkpoint (.pth) for evaluate/visualize modes",
    )
    parser.add_argument(
        "--data_root",
        type=str,
        default=None,
        help="Override the data_root path from the config file",
    )
    parser.add_argument(
        "--device",
        type=str,
        default=None,
        help="Override compute device (cuda, mps, cpu)",
    )

    args = parser.parse_args()

    # Validate: evaluate and visualize modes require a checkpoint
    if args.mode in ("evaluate", "visualize") and args.checkpoint is None:
        parser.error(f"--checkpoint is required for mode '{args.mode}'")

    return args


def create_datasets(
    config: Dict[str, Any],
    train_transform: Any,
    val_test_transform: Any,
) -> Dict[str, Any]:
    """Create train/val/test datasets based on the config dataset name.

    Args:
        config: Configuration dictionary.
        train_transform: Transform pipeline for training data.
        val_test_transform: Transform pipeline for validation/test data.

    Returns:
        Dictionary with 'train', 'val', 'test' dataset instances.

    Raises:
        ValueError: If dataset_name is not recognized.
    """
    dataset_name = config["dataset_name"].lower()
    data_root = config["data_root"]

    if dataset_name == "ucf_crime":
        DatasetClass = UCFCrimeDataset
    elif dataset_name == "rwf2000":
        DatasetClass = RWF2000Dataset
    else:
        raise ValueError(
            f"Unknown dataset: '{dataset_name}'. "
            f"Supported datasets: 'ucf_crime', 'rwf2000'"
        )

    train_dataset = DatasetClass(
        root_dir=data_root, split="train", transform=train_transform, config=config
    )
    val_dataset = DatasetClass(
        root_dir=data_root, split="val", transform=val_test_transform, config=config
    )
    test_dataset = DatasetClass(
        root_dir=data_root, split="test", transform=val_test_transform, config=config
    )

    return {
        "train": train_dataset,
        "val": val_dataset,
        "test": test_dataset,
    }


def run_train(config: Dict[str, Any], device: torch.device) -> None:
    """Execute the full training pipeline.

    Creates datasets, initializes the model and trainer, runs training
    with early stopping, evaluates on the test set, and saves all plots.

    Args:
        config: Configuration dictionary.
        device: Compute device.
    """
    print("\n" + "=" * 60)
    print("TRAINING MODE")
    print("=" * 60)

    # Create output directories
    create_output_dirs(config)

    # Create transforms
    train_transform = get_train_transforms(config)
    val_test_transform = get_val_test_transforms(config)

    # Create datasets
    datasets = create_datasets(config, train_transform, val_test_transform)

    # Create dataloaders
    train_loader = get_dataloader(
        datasets["train"],
        batch_size=config["batch_size"],
        shuffle=True,
        num_workers=config.get("num_workers", 4),
    )
    val_loader = get_dataloader(
        datasets["val"],
        batch_size=config["batch_size"],
        shuffle=False,
        num_workers=config.get("num_workers", 4),
    )
    test_loader = get_dataloader(
        datasets["test"],
        batch_size=config["batch_size"],
        shuffle=False,
        num_workers=config.get("num_workers", 4),
    )

    # Initialize model
    model = get_model(config)
    count_parameters(model)

    # Compute class weights for imbalanced datasets (UCF-Crime)
    class_weights = None
    if config["dataset_name"].lower() == "ucf_crime":
        class_weights = datasets["train"].get_class_weights()
        print(f"[INFO] Class weights computed: {class_weights.numpy().round(3)}")

    # Initialize trainer
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        config=config,
        device=device,
        class_weights=class_weights,
    )

    # Train
    start_time = time.time()
    history = trainer.train()
    total_time = time.time() - start_time
    print(f"\n[INFO] Total training time: {format_time(total_time)}")

    # Plot training history
    plots_dir = os.path.join(config["log_dir"], "plots")
    plot_training_history(
        history, os.path.join(plots_dir, "training_history.png")
    )

    # Evaluate on test set
    print("\n[INFO] Running evaluation on test set...")
    best_checkpoint = os.path.join(config["checkpoint_dir"], "best_model.pth")
    if os.path.exists(best_checkpoint):
        checkpoint = torch.load(best_checkpoint, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])
        print(f"[INFO] Loaded best checkpoint from epoch {checkpoint['epoch']}")

    evaluator = Evaluator(
        model=model,
        test_loader=test_loader,
        config=config,
        device=device,
    )

    metrics = evaluator.evaluate()

    # Save metrics
    save_metrics_to_csv(
        {k: v for k, v in metrics.items() if k != "classification_report"},
        os.path.join(plots_dir, "test_metrics.csv"),
    )

    # Generate plots
    evaluator.plot_confusion_matrix(
        os.path.join(plots_dir, "confusion_matrix.png")
    )
    evaluator.plot_roc_curves(
        os.path.join(plots_dir, "roc_curves.png")
    )
    evaluator.plot_metrics_comparison(
        os.path.join(plots_dir, "metrics_comparison.png")
    )

    print("\n[INFO] Training pipeline complete!")
    print(f"       Best checkpoint: {best_checkpoint}")
    print(f"       Plots saved to : {plots_dir}")


def run_evaluate(
    config: Dict[str, Any], checkpoint_path: str, device: torch.device
) -> None:
    """Execute the evaluation pipeline on a trained checkpoint.

    Loads the model from a checkpoint, runs inference on the test set,
    and generates all evaluation plots.

    Args:
        config: Configuration dictionary.
        checkpoint_path: Path to the model checkpoint file.
        device: Compute device.
    """
    print("\n" + "=" * 60)
    print("EVALUATION MODE")
    print("=" * 60)

    create_output_dirs(config)

    # Load model and checkpoint
    model = get_model(config)

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(
            f"Checkpoint not found: {checkpoint_path}\n"
            f"Please train the model first or provide a valid checkpoint path."
        )

    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model = model.to(device)
    print(
        f"[INFO] Loaded checkpoint: Epoch {checkpoint['epoch']}, "
        f"Val F1: {checkpoint['metrics'].get('val_f1', 'N/A')}"
    )

    # Create test dataset and loader
    val_test_transform = get_val_test_transforms(config)

    dataset_name = config["dataset_name"].lower()
    if dataset_name == "ucf_crime":
        test_dataset = UCFCrimeDataset(
            root_dir=config["data_root"],
            split="test",
            transform=val_test_transform,
            config=config,
        )
    elif dataset_name == "rwf2000":
        test_dataset = RWF2000Dataset(
            root_dir=config["data_root"],
            split="test",
            transform=val_test_transform,
            config=config,
        )
    else:
        raise ValueError(f"Unknown dataset: '{dataset_name}'")

    test_loader = get_dataloader(
        test_dataset,
        batch_size=config["batch_size"],
        shuffle=False,
        num_workers=config.get("num_workers", 4),
    )

    # Evaluate
    evaluator = Evaluator(
        model=model,
        test_loader=test_loader,
        config=config,
        device=device,
    )

    metrics = evaluator.evaluate()

    # Save plots
    plots_dir = os.path.join(config["log_dir"], "plots")
    os.makedirs(plots_dir, exist_ok=True)

    evaluator.plot_confusion_matrix(
        os.path.join(plots_dir, "confusion_matrix.png")
    )
    evaluator.plot_roc_curves(
        os.path.join(plots_dir, "roc_curves.png")
    )
    evaluator.plot_metrics_comparison(
        os.path.join(plots_dir, "metrics_comparison.png")
    )

    save_metrics_to_csv(
        {k: v for k, v in metrics.items() if k != "classification_report"},
        os.path.join(plots_dir, "test_metrics.csv"),
    )

    print(f"\n[INFO] Evaluation complete! Plots saved to: {plots_dir}")


def run_visualize(
    config: Dict[str, Any], checkpoint_path: str, device: torch.device
) -> None:
    """Generate Grad-CAM visualizations from a trained checkpoint.

    Loads the model, runs inference on a batch of test images, and
    generates Grad-CAM heatmap overlays.

    Args:
        config: Configuration dictionary.
        checkpoint_path: Path to the model checkpoint file.
        device: Compute device.
    """
    print("\n" + "=" * 60)
    print("VISUALIZATION MODE (Grad-CAM)")
    print("=" * 60)

    create_output_dirs(config)

    # Load model
    model = get_model(config)

    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(
            f"Checkpoint not found: {checkpoint_path}\n"
            f"Please train the model first or provide a valid checkpoint path."
        )

    checkpoint = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    model = model.to(device)
    model.eval()
    print(f"[INFO] Loaded checkpoint from epoch {checkpoint['epoch']}")

    # Create test dataset
    val_test_transform = get_val_test_transforms(config)

    dataset_name = config["dataset_name"].lower()
    if dataset_name == "ucf_crime":
        test_dataset = UCFCrimeDataset(
            root_dir=config["data_root"],
            split="test",
            transform=val_test_transform,
            config=config,
        )
    elif dataset_name == "rwf2000":
        test_dataset = RWF2000Dataset(
            root_dir=config["data_root"],
            split="test",
            transform=val_test_transform,
            config=config,
        )
    else:
        raise ValueError(f"Unknown dataset: '{dataset_name}'")

    test_loader = get_dataloader(
        test_dataset,
        batch_size=16,
        shuffle=True,  # Shuffle to get varied samples
        num_workers=config.get("num_workers", 4),
    )

    # Get a sample batch
    sample_images, sample_labels = next(iter(test_loader))
    sample_images = sample_images.to(device)

    # Get predictions
    with torch.no_grad():
        logits = model(sample_images)
        _, predictions = torch.max(logits, dim=1)

    # Initialize Grad-CAM
    gradcam = VitGradCAM(model=model, device=device)

    # Generate visualizations
    plots_dir = os.path.join(config["log_dir"], "plots")
    os.makedirs(plots_dir, exist_ok=True)

    gradcam.visualize_batch(
        images=sample_images,
        labels=sample_labels,
        predictions=predictions,
        save_path=os.path.join(plots_dir, "gradcam_visualization.png"),
        class_names=config.get("class_names"),
        max_images=16,
    )

    print(f"\n[INFO] Grad-CAM visualizations saved to: {plots_dir}")


def main() -> None:
    """Main entry point — parses arguments and dispatches to the correct mode."""
    args = parse_args()

    # Load configuration
    config = load_config(args.config)

    # Override data root if specified
    if args.data_root is not None:
        config["data_root"] = args.data_root
        print(f"[INFO] Data root overridden to: {args.data_root}")

    # Set seed for reproducibility
    set_seed(config.get("seed", 42))

    # Determine device
    if args.device is not None:
        device = torch.device(args.device)
        print(f"[INFO] Device overridden to: {args.device}")
    else:
        device = get_device()

    # Dispatch to the appropriate mode
    if args.mode == "train":
        run_train(config, device)

    elif args.mode == "evaluate":
        run_evaluate(config, args.checkpoint, device)

    elif args.mode == "visualize":
        run_visualize(config, args.checkpoint, device)

    else:
        print(f"[ERROR] Unknown mode: {args.mode}")
        sys.exit(1)


if __name__ == "__main__":
    main()

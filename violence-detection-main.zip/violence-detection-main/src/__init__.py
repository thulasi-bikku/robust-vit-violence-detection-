# Violence Detection using Vision Transformer
# Implementation of: "A Generalizable Vision Transformer Framework
# for Low-False-Alarm Violence Detection"

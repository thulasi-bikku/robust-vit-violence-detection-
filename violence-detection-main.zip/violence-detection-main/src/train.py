"""
Training pipeline for the Violence Detection ViT framework.

Implements the Trainer class with:
- AdamW optimizer with lr=1e-5 (per paper specification)
- CrossEntropyLoss with optional class weights for imbalanced datasets
- Early stopping based on validation loss with configurable patience
- TensorBoard logging for loss, accuracy, and F1-score
- Checkpoint saving based on best validation F1-score
"""

import os
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import f1_score
from torch.optim import AdamW
from torch.utils.data import DataLoader
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm

from .utils import format_time


class EarlyStopping:
    """Early stopping to halt training when validation loss stops improving.

    Monitors validation loss and triggers stop if no improvement is seen
    for `patience` consecutive epochs, as described in the paper.

    Attributes:
        patience: Number of epochs to wait for improvement.
        min_delta: Minimum change to qualify as an improvement.
        counter: Current count of epochs without improvement.
        best_loss: Best validation loss observed so far.
        should_stop: Flag indicating whether training should stop.
    """

    def __init__(self, patience: int = 10, min_delta: float = 0.0) -> None:
        """Initialize early stopping tracker.

        Args:
            patience: Number of epochs with no improvement before stopping.
            min_delta: Minimum decrease in loss to count as improvement.
        """
        self.patience = patience
        self.min_delta = min_delta
        self.counter: int = 0
        self.best_loss: float = float("inf")
        self.should_stop: bool = False

    def __call__(self, val_loss: float) -> bool:
        """Check if training should stop.

        Args:
            val_loss: Current epoch's validation loss.

        Returns:
            True if training should stop, False otherwise.
        """
        if val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.should_stop = True

        return self.should_stop


class Trainer:
    """Full training pipeline for the ViT violence classifier.

    Manages the complete training lifecycle including optimization,
    validation, early stopping, checkpointing, and TensorBoard logging.

    Attributes:
        model: The ViT model to train.
        train_loader: DataLoader for training data.
        val_loader: DataLoader for validation data.
        config: Configuration dictionary.
        device: Compute device (cuda/mps/cpu).
        optimizer: AdamW optimizer instance.
        criterion: CrossEntropyLoss (potentially weighted).
        early_stopping: Early stopping tracker.
        writer: TensorBoard SummaryWriter.
    """

    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        config: Dict[str, Any],
        device: torch.device,
        class_weights: Optional[torch.Tensor] = None,
    ) -> None:
        """Initialize the Trainer.

        Args:
            model: ViT model to train.
            train_loader: DataLoader for the training set.
            val_loader: DataLoader for the validation set.
            config: Configuration dictionary with training hyperparameters.
            device: Target compute device.
            class_weights: Optional tensor of per-class weights for
                           handling class imbalance (used with UCF-Crime).
        """
        self.model = model.to(device)
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.config = config
        self.device = device

        # AdamW optimizer as specified in the paper
        self.optimizer = AdamW(
            self.model.parameters(),
            lr=config["learning_rate"],
            weight_decay=config.get("weight_decay", 0.01),
        )

        # CrossEntropyLoss with optional class weights
        if class_weights is not None:
            class_weights = class_weights.to(device)
            self.criterion = nn.CrossEntropyLoss(weight=class_weights)
            print("[INFO] Using weighted CrossEntropyLoss for class imbalance")
        else:
            self.criterion = nn.CrossEntropyLoss()

        # Early stopping
        self.early_stopping = EarlyStopping(
            patience=config.get("early_stopping_patience", 10)
        )

        # TensorBoard
        log_dir = config.get("log_dir", "./outputs/logs")
        os.makedirs(log_dir, exist_ok=True)
        self.writer = SummaryWriter(log_dir=log_dir)

        # Best model tracking
        self.best_val_f1: float = 0.0
        self.best_epoch: int = 0

        print(
            f"[INFO] Trainer initialized:"
            f"\n       Optimizer : AdamW (lr={config['learning_rate']})"
            f"\n       Patience  : {config.get('early_stopping_patience', 10)}"
            f"\n       Device    : {device}"
        )

    def train_one_epoch(self, epoch: int) -> Tuple[float, float, float]:
        """Train for a single epoch.

        Args:
            epoch: Current epoch number (for logging).

        Returns:
            Tuple of (epoch_loss, epoch_accuracy, epoch_f1).
        """
        self.model.train()
        running_loss = 0.0
        correct = 0
        total = 0
        all_preds: List[int] = []
        all_labels: List[int] = []

        pbar = tqdm(
            self.train_loader,
            desc=f"Epoch {epoch} [Train]",
            leave=False,
            ncols=100,
        )

        for batch_idx, (images, labels) in enumerate(pbar):
            images = images.to(self.device)
            labels = labels.to(self.device)

            # Forward pass
            self.optimizer.zero_grad()
            logits = self.model(images)
            loss = self.criterion(logits, labels)

            # Backward pass
            loss.backward()
            self.optimizer.step()

            # Track metrics
            running_loss += loss.item() * images.size(0)
            _, predicted = torch.max(logits, dim=1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()

            all_preds.extend(predicted.cpu().numpy().tolist())
            all_labels.extend(labels.cpu().numpy().tolist())

            # Update progress bar
            pbar.set_postfix(
                loss=f"{loss.item():.4f}",
                acc=f"{100.0 * correct / total:.1f}%",
            )

        epoch_loss = running_loss / total
        epoch_acc = 100.0 * correct / total
        epoch_f1 = f1_score(all_labels, all_preds, average="macro", zero_division=0)

        return epoch_loss, epoch_acc, epoch_f1

    def validate(self) -> Tuple[float, float, float]:
        """Run validation and compute metrics.

        Returns:
            Tuple of (val_loss, val_accuracy, val_f1).
        """
        self.model.eval()
        running_loss = 0.0
        correct = 0
        total = 0
        all_preds: List[int] = []
        all_labels: List[int] = []

        with torch.no_grad():
            pbar = tqdm(
                self.val_loader,
                desc="         [Val]  ",
                leave=False,
                ncols=100,
            )

            for images, labels in pbar:
                images = images.to(self.device)
                labels = labels.to(self.device)

                logits = self.model(images)
                loss = self.criterion(logits, labels)

                running_loss += loss.item() * images.size(0)
                _, predicted = torch.max(logits, dim=1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

                all_preds.extend(predicted.cpu().numpy().tolist())
                all_labels.extend(labels.cpu().numpy().tolist())

        val_loss = running_loss / total
        val_acc = 100.0 * correct / total
        val_f1 = f1_score(all_labels, all_preds, average="macro", zero_division=0)

        return val_loss, val_acc, val_f1

    def train(self) -> Dict[str, List[float]]:
        """Execute the full training loop with early stopping.

        Trains for up to `num_epochs` epochs, applying early stopping if
        validation loss does not improve for `patience` consecutive epochs.
        Saves the best model checkpoint based on validation F1-score.

        Returns:
            Training history dictionary with keys:
            'train_loss', 'train_acc', 'train_f1',
            'val_loss', 'val_acc', 'val_f1'.
        """
        num_epochs = self.config["num_epochs"]

        history: Dict[str, List[float]] = {
            "train_loss": [],
            "train_acc": [],
            "train_f1": [],
            "val_loss": [],
            "val_acc": [],
            "val_f1": [],
        }

        print("\n" + "=" * 90)
        print(f"{'Epoch':>6} | {'Train Loss':>11} | {'Train Acc':>10} | {'Train F1':>9} | "
              f"{'Val Loss':>9} | {'Val Acc':>8} | {'Val F1':>7} | {'Time':>8}")
        print("=" * 90)

        total_start = time.time()

        for epoch in range(1, num_epochs + 1):
            epoch_start = time.time()

            # Train
            train_loss, train_acc, train_f1 = self.train_one_epoch(epoch)

            # Validate
            val_loss, val_acc, val_f1 = self.validate()

            epoch_time = time.time() - epoch_start

            # Record history
            history["train_loss"].append(train_loss)
            history["train_acc"].append(train_acc)
            history["train_f1"].append(train_f1)
            history["val_loss"].append(val_loss)
            history["val_acc"].append(val_acc)
            history["val_f1"].append(val_f1)

            # TensorBoard logging
            self.writer.add_scalar("Loss/train", train_loss, epoch)
            self.writer.add_scalar("Loss/val", val_loss, epoch)
            self.writer.add_scalar("Accuracy/train", train_acc, epoch)
            self.writer.add_scalar("Accuracy/val", val_acc, epoch)
            self.writer.add_scalar("F1/train", train_f1, epoch)
            self.writer.add_scalar("F1/val", val_f1, epoch)
            self.writer.add_scalar("LR", self.optimizer.param_groups[0]["lr"], epoch)

            # Save best model based on val F1
            marker = ""
            if val_f1 > self.best_val_f1:
                self.best_val_f1 = val_f1
                self.best_epoch = epoch
                checkpoint_path = os.path.join(
                    self.config["checkpoint_dir"], "best_model.pth"
                )
                self.save_checkpoint(
                    checkpoint_path,
                    epoch,
                    {"val_loss": val_loss, "val_acc": val_acc, "val_f1": val_f1},
                )
                marker = " ★"

            # Print epoch summary
            print(
                f"{epoch:>6} | {train_loss:>11.4f} | {train_acc:>9.2f}% | {train_f1:>9.4f} | "
                f"{val_loss:>9.4f} | {val_acc:>7.2f}% | {val_f1:>7.4f} | "
                f"{format_time(epoch_time):>8}{marker}"
            )

            # Early stopping check
            if self.early_stopping(val_loss):
                print(
                    f"\n[INFO] Early stopping triggered at epoch {epoch}. "
                    f"No improvement for {self.early_stopping.patience} epochs."
                )
                break

        total_time = time.time() - total_start
        print("=" * 90)
        print(
            f"[INFO] Training complete in {format_time(total_time)}. "
            f"Best epoch: {self.best_epoch} (Val F1: {self.best_val_f1:.4f})"
        )

        self.writer.close()
        return history

    def save_checkpoint(
        self, path: str, epoch: int, metrics: Dict[str, float]
    ) -> None:
        """Save a model checkpoint.

        Saves model state dict, optimizer state, epoch, metrics, and
        the full config for reproducibility.

        Args:
            path: Filesystem path for the checkpoint file.
            epoch: Current epoch number.
            metrics: Dictionary of validation metrics at this epoch.
        """
        os.makedirs(os.path.dirname(path), exist_ok=True)

        checkpoint = {
            "epoch": epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "metrics": metrics,
            "config": self.config,
        }

        torch.save(checkpoint, path)
        print(f"[INFO] Checkpoint saved: {path} (Epoch {epoch}, Val F1: {metrics.get('val_f1', 0):.4f})")

    def load_checkpoint(self, path: str) -> Dict[str, Any]:
        """Load a model checkpoint.

        Args:
            path: Path to the checkpoint file.

        Returns:
            Checkpoint dictionary with epoch, metrics, and config.

        Raises:
            FileNotFoundError: If the checkpoint file does not exist.
        """
        if not os.path.exists(path):
            raise FileNotFoundError(f"Checkpoint not found: {path}")

        checkpoint = torch.load(path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])

        print(
            f"[INFO] Checkpoint loaded: {path} "
            f"(Epoch {checkpoint['epoch']}, "
            f"Val F1: {checkpoint['metrics'].get('val_f1', 0):.4f})"
        )

        return checkpoint

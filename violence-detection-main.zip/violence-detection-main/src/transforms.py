"""
Data augmentation and preprocessing transforms for the Violence Detection framework.

Implements the exact augmentation pipeline described in Table 2 of the paper:
- RandomRotation: degrees=(-10, 10)
- RandomHorizontalFlip: p=0.5
- RandomResizedCrop: scale=(0.8, 1.2), size=224
- GaussianBlur: sigma=(0.1, 2.0)
- ColorJitter: brightness=0.2, contrast=0.2
- Normalize: mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5]
"""

from typing import Any, Dict

from torchvision import transforms


def get_train_transforms(config: Dict[str, Any]) -> transforms.Compose:
    """Build the training augmentation pipeline as described in the paper (Table 2).

    Applies aggressive augmentation to improve generalization and reduce
    overfitting, especially important for the imbalanced UCF-Crime dataset.

    Args:
        config: Configuration dictionary containing at minimum 'img_size'.

    Returns:
        A torchvision.transforms.Compose object for training data.
    """
    img_size = config["img_size"]

    transform = transforms.Compose(
        [
            transforms.ToPILImage(),
            transforms.RandomRotation(degrees=(-10, 10)),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomResizedCrop(
                size=img_size,
                scale=(0.8, 1.0),  # scale range for crop area ratio
                ratio=(0.9, 1.1),  # aspect ratio range
            ),
            transforms.GaussianBlur(kernel_size=5, sigma=(0.1, 2.0)),
            transforms.ColorJitter(brightness=0.2, contrast=0.2),
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.5, 0.5, 0.5],
                std=[0.5, 0.5, 0.5],
            ),
        ]
    )

    return transform


def get_val_test_transforms(config: Dict[str, Any]) -> transforms.Compose:
    """Build the validation/test preprocessing pipeline (no augmentation).

    Only resizes and normalizes — no stochastic augmentation is applied
    during evaluation to ensure deterministic and fair metric computation.

    Args:
        config: Configuration dictionary containing at minimum 'img_size'.

    Returns:
        A torchvision.transforms.Compose object for validation/test data.
    """
    img_size = config["img_size"]

    transform = transforms.Compose(
        [
            transforms.ToPILImage(),
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.5, 0.5, 0.5],
                std=[0.5, 0.5, 0.5],
            ),
        ]
    )

    return transform

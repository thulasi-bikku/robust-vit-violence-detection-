"""
Vision Transformer (ViT) model for violence classification.

Implements the ViTViolenceClassifier as described in the paper:
- Backbone: vit_base_patch16_224 from the timm library
- Input: 224x224 RGB frames, patchified into 16x16 patches
- [CLS] token dimension: 768
- Classification head: Linear(768, num_classes)
- Output: Raw logits (CrossEntropyLoss handles softmax internally)
"""

from typing import Any, Dict, Optional

import timm
import torch
import torch.nn as nn


class ViTViolenceClassifier(nn.Module):
    """Vision Transformer classifier for violence detection.

    Uses a pretrained ViT-Base/16 backbone from the timm library, replacing
    the original ImageNet classification head with a task-specific linear
    layer for violence category prediction.

    The [CLS] token output (dimension 768 for vit_base_patch16_224) is
    fed through the new classification head to produce logits.

    Attributes:
        vit: The timm ViT backbone model.
        classifier: Linear classification head mapping [CLS] → num_classes.
        num_classes: Number of output classes.
    """

    def __init__(
        self,
        num_classes: int,
        pretrained: bool = True,
        model_name: str = "vit_base_patch16_224",
    ) -> None:
        """Initialize the ViT violence classifier.

        Args:
            num_classes: Number of target classes (14 for UCF-Crime, 2 for RWF-2000).
            pretrained: Whether to load ImageNet-pretrained weights.
            model_name: timm model identifier. Default is vit_base_patch16_224.
        """
        super().__init__()

        self.num_classes = num_classes

        # Load pretrained ViT from timm with no built-in classification head
        self.vit = timm.create_model(
            model_name,
            pretrained=pretrained,
            num_classes=0,  # Remove default head; we get [CLS] token output
        )

        # The [CLS] token dimension for vit_base_patch16_224 is 768
        cls_dim = self.vit.num_features  # 768 for base model

        # Custom classification head
        self.classifier = nn.Linear(cls_dim, num_classes)

        print(
            f"[INFO] ViTViolenceClassifier initialized:"
            f"\n       Backbone   : {model_name}"
            f"\n       Pretrained : {pretrained}"
            f"\n       [CLS] dim  : {cls_dim}"
            f"\n       Num classes: {num_classes}"
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Forward pass through the ViT encoder and classification head.

        Args:
            x: Input tensor of shape (B, 3, 224, 224).

        Returns:
            Logits tensor of shape (B, num_classes). NOT softmax-normalized;
            use CrossEntropyLoss which applies log-softmax internally.
        """
        # Extract [CLS] token features from ViT backbone
        cls_features = self.vit(x)  # (B, 768)
        logits = self.classifier(cls_features)  # (B, num_classes)
        return logits

    def get_attention_maps(self, x: torch.Tensor) -> torch.Tensor:
        """Extract attention weights from the last transformer encoder layer.

        Registers a forward hook on the last attention block to capture
        the attention matrix, then runs a forward pass.

        Args:
            x: Input tensor of shape (B, 3, 224, 224).

        Returns:
            Attention weight tensor of shape (B, num_heads, num_patches+1, num_patches+1).
        """
        attention_weights = []

        def hook_fn(module: nn.Module, input: Any, output: Any) -> None:
            """Hook to capture attention weights from the QKV attention layer."""
            attention_weights.append(output)

        # The last transformer block's attention layer
        last_block = self.vit.blocks[-1]
        attn_layer = last_block.attn

        # Register hook on the attention dropout (after softmax attention)
        handle = attn_layer.attn_drop.register_forward_hook(hook_fn)

        # Forward pass to trigger the hook
        with torch.no_grad():
            _ = self.forward(x)

        handle.remove()

        if attention_weights:
            return attention_weights[0]
        else:
            # Fallback: return empty tensor if hook didn't fire
            print("[WARNING] Attention hook did not capture any weights.")
            num_patches = (x.shape[-1] // 16) ** 2 + 1  # +1 for [CLS]
            return torch.zeros(x.shape[0], 12, num_patches, num_patches)

    def get_features(self, x: torch.Tensor) -> torch.Tensor:
        """Extract the [CLS] token features without classification.

        Useful for feature visualization and embedding analysis.

        Args:
            x: Input tensor of shape (B, 3, 224, 224).

        Returns:
            Feature tensor of shape (B, 768).
        """
        return self.vit(x)


def get_model(config: Dict[str, Any]) -> ViTViolenceClassifier:
    """Factory function to create a ViTViolenceClassifier from config.

    Args:
        config: Configuration dictionary with 'num_classes' and optional
                'model_name' keys.

    Returns:
        Initialized ViTViolenceClassifier instance.
    """
    model = ViTViolenceClassifier(
        num_classes=config["num_classes"],
        pretrained=True,
        model_name=config.get("model_name", "vit_base_patch16_224"),
    )
    return model

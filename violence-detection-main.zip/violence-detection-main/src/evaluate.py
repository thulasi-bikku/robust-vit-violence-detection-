"""
Evaluation pipeline for the Violence Detection ViT framework.

Implements the Evaluator class with comprehensive metric computation:
- Accuracy, Precision (macro), Recall (macro), F1-Score (macro)
- ROC AUC (macro, one-vs-rest)
- Per-class precision, recall, F1
- Full sklearn classification_report
- Confusion matrix heatmap (matching Figure 4 style)
- ROC curves per class
- Metrics comparison bar chart (matching Figure 6 style)
"""

import os
from typing import Any, Dict, List, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import torch
import torch.nn as nn
from sklearn.metrics import (
    accuracy_score,
    auc,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.preprocessing import label_binarize
from torch.utils.data import DataLoader
from tqdm import tqdm


class Evaluator:
    """Full evaluation pipeline for the trained ViT violence classifier.

    Computes all metrics reported in the paper and generates publication-
    quality visualizations including confusion matrices, ROC curves, and
    metrics comparison bar charts.

    Attributes:
        model: Trained ViT model to evaluate.
        test_loader: DataLoader for the test set.
        config: Configuration dictionary.
        device: Compute device.
        class_names: List of class name strings.
        num_classes: Number of target classes.
    """

    def __init__(
        self,
        model: nn.Module,
        test_loader: DataLoader,
        config: Dict[str, Any],
        device: torch.device,
    ) -> None:
        """Initialize the Evaluator.

        Args:
            model: Trained ViT model (should already have weights loaded).
            test_loader: DataLoader for the test set.
            config: Configuration dictionary.
            device: Target compute device.
        """
        self.model = model.to(device)
        self.test_loader = test_loader
        self.config = config
        self.device = device
        self.class_names: List[str] = config.get("class_names", [])
        self.num_classes: int = config.get("num_classes", len(self.class_names))

        # Will be populated after evaluate() is called
        self.all_labels: List[int] = []
        self.all_preds: List[int] = []
        self.all_probs: List[np.ndarray] = []

    def evaluate(self) -> Dict[str, Any]:
        """Run full evaluation on the test set.

        Computes all metrics as reported in the paper: accuracy, macro
        precision, recall, F1-score, and ROC AUC (one-vs-rest).

        Returns:
            Dictionary containing:
            - 'accuracy': Overall accuracy percentage
            - 'precision_macro': Macro-averaged precision
            - 'recall_macro': Macro-averaged recall
            - 'f1_macro': Macro-averaged F1-score
            - 'roc_auc_macro': Macro-averaged ROC AUC
            - 'per_class_precision': Per-class precision array
            - 'per_class_recall': Per-class recall array
            - 'per_class_f1': Per-class F1 array
            - 'classification_report': Full text report
        """
        self.model.eval()
        self.all_labels = []
        self.all_preds = []
        self.all_probs = []

        with torch.no_grad():
            pbar = tqdm(
                self.test_loader,
                desc="[Evaluate]",
                leave=True,
                ncols=100,
            )

            for images, labels in pbar:
                images = images.to(self.device)
                labels = labels.to(self.device)

                logits = self.model(images)
                probs = torch.softmax(logits, dim=1)
                _, predicted = torch.max(logits, dim=1)

                self.all_labels.extend(labels.cpu().numpy().tolist())
                self.all_preds.extend(predicted.cpu().numpy().tolist())
                self.all_probs.extend(probs.cpu().numpy())

        labels_np = np.array(self.all_labels)
        preds_np = np.array(self.all_preds)
        probs_np = np.array(self.all_probs)

        # --- Overall Metrics ---
        accuracy = accuracy_score(labels_np, preds_np) * 100.0
        precision_macro = precision_score(
            labels_np, preds_np, average="macro", zero_division=0
        )
        recall_macro = recall_score(
            labels_np, preds_np, average="macro", zero_division=0
        )
        f1_macro = f1_score(
            labels_np, preds_np, average="macro", zero_division=0
        )

        # --- ROC AUC (one-vs-rest, macro) ---
        try:
            if self.num_classes == 2:
                roc_auc_macro = roc_auc_score(labels_np, probs_np[:, 1])
            else:
                labels_bin = label_binarize(
                    labels_np, classes=list(range(self.num_classes))
                )
                roc_auc_macro = roc_auc_score(
                    labels_bin, probs_np, average="macro", multi_class="ovr"
                )
        except ValueError as e:
            print(f"[WARNING] ROC AUC computation failed: {e}")
            roc_auc_macro = 0.0

        # --- Per-class Metrics ---
        per_precision, per_recall, per_f1, per_support = precision_recall_fscore_support(
            labels_np, preds_np, average=None, zero_division=0
        )

        # --- Classification Report ---
        target_names = (
            self.class_names if len(self.class_names) == self.num_classes else None
        )
        report = classification_report(
            labels_np,
            preds_np,
            target_names=target_names,
            zero_division=0,
        )

        # Print results
        print("\n" + "=" * 60)
        print("EVALUATION RESULTS")
        print("=" * 60)
        print(f"  Accuracy       : {accuracy:.2f}%")
        print(f"  Precision (M)  : {precision_macro:.4f}")
        print(f"  Recall (M)     : {recall_macro:.4f}")
        print(f"  F1-Score (M)   : {f1_macro:.4f}")
        print(f"  ROC AUC (M)    : {roc_auc_macro:.4f}")
        print("-" * 60)
        print("\nFull Classification Report:")
        print(report)
        print("=" * 60)

        metrics = {
            "accuracy": accuracy,
            "precision_macro": precision_macro,
            "recall_macro": recall_macro,
            "f1_macro": f1_macro,
            "roc_auc_macro": roc_auc_macro,
            "per_class_precision": per_precision.tolist(),
            "per_class_recall": per_recall.tolist(),
            "per_class_f1": per_f1.tolist(),
            "per_class_support": per_support.tolist(),
            "classification_report": report,
        }

        return metrics

    def plot_confusion_matrix(self, save_path: str) -> None:
        """Generate and save a confusion matrix heatmap.

        Styled to match Figure 4 of the paper: dark-themed heatmap with
        actual counts displayed in each cell, class labels on axes.

        Args:
            save_path: Filesystem path to save the plot.

        Raises:
            RuntimeError: If evaluate() has not been called first.
        """
        if not self.all_labels:
            raise RuntimeError("Call evaluate() before plotting confusion matrix.")

        labels_np = np.array(self.all_labels)
        preds_np = np.array(self.all_preds)

        cm = confusion_matrix(labels_np, preds_np)

        fig, ax = plt.subplots(
            figsize=(max(10, self.num_classes * 0.8), max(8, self.num_classes * 0.7))
        )

        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            xticklabels=self.class_names if self.class_names else "auto",
            yticklabels=self.class_names if self.class_names else "auto",
            linewidths=0.5,
            linecolor="gray",
            ax=ax,
            cbar_kws={"shrink": 0.8},
        )

        ax.set_xlabel("Predicted Label", fontsize=13, fontweight="bold")
        ax.set_ylabel("True Label", fontsize=13, fontweight="bold")
        ax.set_title(
            f"Confusion Matrix — {self.config.get('dataset_name', 'Dataset')}",
            fontsize=15,
            fontweight="bold",
            pad=15,
        )

        plt.xticks(rotation=45, ha="right", fontsize=10)
        plt.yticks(rotation=0, fontsize=10)
        plt.tight_layout()

        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"[INFO] Confusion matrix saved to: {save_path}")

    def plot_roc_curves(self, save_path: str) -> None:
        """Generate and save per-class ROC curves.

        Plots one ROC curve per class using one-vs-rest binarization,
        with the macro-average AUC annotated in the legend.

        Args:
            save_path: Filesystem path to save the plot.

        Raises:
            RuntimeError: If evaluate() has not been called first.
        """
        if not self.all_labels:
            raise RuntimeError("Call evaluate() before plotting ROC curves.")

        labels_np = np.array(self.all_labels)
        probs_np = np.array(self.all_probs)

        if self.num_classes == 2:
            # Binary case
            fig, ax = plt.subplots(figsize=(8, 6))

            fpr, tpr, _ = roc_curve(labels_np, probs_np[:, 1])
            roc_auc = auc(fpr, tpr)

            ax.plot(
                fpr, tpr,
                linewidth=2,
                label=f"{self.class_names[1] if self.class_names else 'Positive'} "
                      f"(AUC = {roc_auc:.3f})",
            )
        else:
            # Multi-class: one-vs-rest
            labels_bin = label_binarize(
                labels_np, classes=list(range(self.num_classes))
            )

            fig, ax = plt.subplots(figsize=(10, 8))
            colors = plt.cm.Set3(np.linspace(0, 1, self.num_classes))

            for i in range(self.num_classes):
                fpr, tpr, _ = roc_curve(labels_bin[:, i], probs_np[:, i])
                roc_auc = auc(fpr, tpr)

                class_name = (
                    self.class_names[i] if i < len(self.class_names) else f"Class {i}"
                )
                ax.plot(
                    fpr, tpr,
                    color=colors[i],
                    linewidth=2,
                    label=f"{class_name} (AUC = {roc_auc:.3f})",
                )

        # Diagonal reference line
        ax.plot([0, 1], [0, 1], "k--", linewidth=1, alpha=0.5, label="Random")

        ax.set_xlabel("False Positive Rate", fontsize=13, fontweight="bold")
        ax.set_ylabel("True Positive Rate", fontsize=13, fontweight="bold")
        ax.set_title(
            f"ROC Curves — {self.config.get('dataset_name', 'Dataset')}",
            fontsize=15,
            fontweight="bold",
            pad=15,
        )
        ax.legend(loc="lower right", fontsize=9, framealpha=0.9)
        ax.grid(True, alpha=0.3)
        ax.set_xlim([-0.01, 1.01])
        ax.set_ylim([-0.01, 1.01])

        plt.tight_layout()
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"[INFO] ROC curves saved to: {save_path}")

    def plot_metrics_comparison(self, save_path: str) -> None:
        """Generate a grouped bar chart comparing Precision, Recall, and F1.

        Styled to match Figure 6 of the paper: per-class grouped bars
        with a clean, professional color palette.

        Args:
            save_path: Filesystem path to save the plot.

        Raises:
            RuntimeError: If evaluate() has not been called first.
        """
        if not self.all_labels:
            raise RuntimeError("Call evaluate() before plotting metrics comparison.")

        labels_np = np.array(self.all_labels)
        preds_np = np.array(self.all_preds)

        per_precision, per_recall, per_f1, _ = precision_recall_fscore_support(
            labels_np, preds_np, average=None, zero_division=0
        )

        x = np.arange(self.num_classes)
        width = 0.25

        fig, ax = plt.subplots(
            figsize=(max(12, self.num_classes * 1.2), 6)
        )

        bars_p = ax.bar(
            x - width, per_precision, width,
            label="Precision", color="#3498db", edgecolor="white", linewidth=0.5,
        )
        bars_r = ax.bar(
            x, per_recall, width,
            label="Recall", color="#e74c3c", edgecolor="white", linewidth=0.5,
        )
        bars_f = ax.bar(
            x + width, per_f1, width,
            label="F1-Score", color="#2ecc71", edgecolor="white", linewidth=0.5,
        )

        ax.set_xlabel("Class", fontsize=13, fontweight="bold")
        ax.set_ylabel("Score", fontsize=13, fontweight="bold")
        ax.set_title(
            f"Per-Class Metrics — {self.config.get('dataset_name', 'Dataset')}",
            fontsize=15,
            fontweight="bold",
            pad=15,
        )
        ax.set_xticks(x)
        ax.set_xticklabels(
            self.class_names if self.class_names else [f"C{i}" for i in range(self.num_classes)],
            rotation=45,
            ha="right",
            fontsize=10,
        )
        ax.set_ylim([0, 1.1])
        ax.legend(fontsize=11, loc="upper right")
        ax.grid(True, axis="y", alpha=0.3)

        plt.tight_layout()
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"[INFO] Metrics comparison chart saved to: {save_path}")

"""
Dataset classes for the Violence Detection ViT framework.

Implements two dataset classes:
1. UCFCrimeDataset - 14-class violence classification from UCF-Crime
2. RWF2000Dataset  - Binary fight/non-fight from RWF-2000

Both datasets:
- Read videos using OpenCV
- Uniformly sample `frames_per_video` frames per video
- Split at the VIDEO level (not frame level) for fair evaluation
- Support class weight computation for imbalanced datasets
"""

import os
import random
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch
from sklearn.utils.class_weight import compute_class_weight
from torch.utils.data import DataLoader, Dataset


def _extract_frames_from_video(
    video_path: str, num_frames: int, img_size: int
) -> List[np.ndarray]:
    """Uniformly sample frames from a video file using OpenCV.

    Divides the video into `num_frames` equal segments and picks the
    middle frame of each segment for a uniform temporal coverage.

    Args:
        video_path: Absolute path to the video file (.mp4 or .avi).
        num_frames: Number of frames to sample uniformly.
        img_size: Target spatial resolution (img_size x img_size).

    Returns:
        List of numpy arrays of shape (H, W, 3) in RGB order.

    Raises:
        RuntimeError: If the video cannot be opened.
    """
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {video_path}")

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if total_frames <= 0:
        cap.release()
        raise RuntimeError(f"Video has no frames: {video_path}")

    # Compute uniform indices
    if total_frames >= num_frames:
        indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
    else:
        # If video has fewer frames than requested, sample with repetition
        indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)

    frames: List[np.ndarray] = []
    for idx in indices:
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(idx))
        ret, frame = cap.read()
        if ret:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            frame = cv2.resize(frame, (img_size, img_size))
            frames.append(frame)
        else:
            # If frame read fails, duplicate last good frame or create blank
            if frames:
                frames.append(frames[-1].copy())
            else:
                frames.append(np.zeros((img_size, img_size, 3), dtype=np.uint8))

    cap.release()
    return frames


def _split_videos(
    video_paths: List[str],
    labels: List[int],
    train_ratio: float,
    val_ratio: float,
    test_ratio: float,
    seed: int,
) -> Dict[str, Tuple[List[str], List[int]]]:
    """Split video paths into train/val/test at the VIDEO level.

    Performs stratified splitting to maintain class distribution across
    splits, using the configured seed for reproducibility.

    Args:
        video_paths: List of video file paths.
        labels: Corresponding integer label for each video.
        train_ratio: Fraction for training set (e.g. 0.70).
        val_ratio: Fraction for validation set (e.g. 0.15).
        test_ratio: Fraction for test set (e.g. 0.15).
        seed: Random seed for reproducible splitting.

    Returns:
        Dictionary with keys 'train', 'val', 'test', each mapping to
        a tuple of (video_paths_list, labels_list).
    """
    rng = random.Random(seed)

    # Group videos by class for stratified splitting
    class_videos: Dict[int, List[Tuple[str, int]]] = {}
    for path, label in zip(video_paths, labels):
        class_videos.setdefault(label, []).append((path, label))

    splits: Dict[str, Tuple[List[str], List[int]]] = {
        "train": ([], []),
        "val": ([], []),
        "test": ([], []),
    }

    for label in sorted(class_videos.keys()):
        items = class_videos[label]
        rng.shuffle(items)

        n = len(items)
        n_train = max(1, int(n * train_ratio))
        n_val = max(1, int(n * val_ratio))
        # Remaining goes to test
        n_test = n - n_train - n_val
        if n_test < 0:
            n_test = 0
            n_val = n - n_train

        train_items = items[:n_train]
        val_items = items[n_train : n_train + n_val]
        test_items = items[n_train + n_val :]

        for item in train_items:
            splits["train"][0].append(item[0])
            splits["train"][1].append(item[1])
        for item in val_items:
            splits["val"][0].append(item[0])
            splits["val"][1].append(item[1])
        for item in test_items:
            splits["test"][0].append(item[0])
            splits["test"][1].append(item[1])

    return splits


class UCFCrimeDataset(Dataset):
    """UCF-Crime dataset for 14-class violence classification.

    Expected folder structure:
        data/UCF_Crime/
        ├── Normal/
        │   └── *.mp4 or *.avi
        ├── Abuse/
        ├── Arrest/
        ├── Assault/
        ├── Burglary/
        ├── Explosion/
        ├── Fighting/
        ├── RoadAccidents/
        ├── Robbery/
        ├── Shooting/
        ├── Shoplifting/
        ├── Stealing/
        ├── Vandalism/
        └── Arson/

    Each video is uniformly sampled into `frames_per_video` frames.
    Items are returned as (frame_tensor, label_int) pairs — one per frame.
    Splitting is performed at the VIDEO level for fair evaluation.
    """

    VIDEO_EXTENSIONS = {".mp4", ".avi", ".mkv", ".mov", ".wmv"}

    def __init__(
        self,
        root_dir: str,
        split: str,
        transform: Optional[Callable] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize UCF-Crime dataset.

        Args:
            root_dir: Path to the UCF_Crime data directory.
            split: One of 'train', 'val', or 'test'.
            transform: Optional transform to apply to each frame.
            config: Configuration dictionary with dataset parameters.

        Raises:
            FileNotFoundError: If root_dir does not exist.
            ValueError: If split is not one of 'train', 'val', 'test'.
        """
        if not os.path.isdir(root_dir):
            raise FileNotFoundError(
                f"Dataset root directory not found: {root_dir}\n"
                f"Please download the UCF-Crime dataset and place it at: {root_dir}\n"
                f"Download: https://www.crcv.ucf.edu/projects/real-world/"
            )

        if split not in ("train", "val", "test"):
            raise ValueError(f"split must be 'train', 'val', or 'test', got '{split}'")

        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.config = config or {}

        self.class_names: List[str] = self.config.get(
            "class_names",
            [
                "Normal", "Abuse", "Arrest", "Assault", "Burglary",
                "Explosion", "Fighting", "RoadAccidents", "Robbery",
                "Shooting", "Shoplifting", "Stealing", "Vandalism", "Arson",
            ],
        )
        self.class_to_idx = {name: i for i, name in enumerate(self.class_names)}
        self.frames_per_video = self.config.get("frames_per_video", 30)
        self.img_size = self.config.get("img_size", 224)
        self.seed = self.config.get("seed", 42)

        # Discover all videos
        all_video_paths: List[str] = []
        all_labels: List[int] = []

        for class_name in self.class_names:
            class_dir = os.path.join(root_dir, class_name)
            if not os.path.isdir(class_dir):
                print(f"[WARNING] Class directory not found: {class_dir}")
                continue

            for fname in sorted(os.listdir(class_dir)):
                ext = os.path.splitext(fname)[1].lower()
                if ext in self.VIDEO_EXTENSIONS:
                    all_video_paths.append(os.path.join(class_dir, fname))
                    all_labels.append(self.class_to_idx[class_name])

        if not all_video_paths:
            raise FileNotFoundError(
                f"No video files found in {root_dir}. "
                f"Expected subdirectories: {self.class_names}"
            )

        # Split at video level
        splits_dict = _split_videos(
            all_video_paths,
            all_labels,
            train_ratio=self.config.get("train_split", 0.70),
            val_ratio=self.config.get("val_split", 0.15),
            test_ratio=self.config.get("test_split", 0.15),
            seed=self.seed,
        )

        self.video_paths, self.video_labels = splits_dict[split]

        # Pre-expand video-level to frame-level index
        self.frame_index: List[Tuple[int, int]] = []  # (video_idx, frame_idx)
        for vid_idx in range(len(self.video_paths)):
            for frame_idx in range(self.frames_per_video):
                self.frame_index.append((vid_idx, frame_idx))

        # Cache extracted frames lazily
        self._frame_cache: Dict[int, List[np.ndarray]] = {}

        print(
            f"[INFO] UCF-Crime {split} set: {len(self.video_paths)} videos, "
            f"{len(self.frame_index)} frames"
        )

    def _load_video_frames(self, video_idx: int) -> List[np.ndarray]:
        """Load and cache frames from a video.

        Args:
            video_idx: Index into self.video_paths.

        Returns:
            List of RGB frames as numpy arrays.
        """
        if video_idx not in self._frame_cache:
            try:
                frames = _extract_frames_from_video(
                    self.video_paths[video_idx],
                    self.frames_per_video,
                    self.img_size,
                )
            except RuntimeError as e:
                print(f"[WARNING] {e} — returning blank frames")
                frames = [
                    np.zeros((self.img_size, self.img_size, 3), dtype=np.uint8)
                    for _ in range(self.frames_per_video)
                ]
            self._frame_cache[video_idx] = frames
        return self._frame_cache[video_idx]

    def __len__(self) -> int:
        """Return the total number of frames across all videos."""
        return len(self.frame_index)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        """Get a single frame and its label.

        Args:
            idx: Index into the frame-level dataset.

        Returns:
            Tuple of (frame_tensor, label_int).
        """
        video_idx, frame_idx = self.frame_index[idx]
        frames = self._load_video_frames(video_idx)
        frame = frames[frame_idx]  # (H, W, 3) uint8 RGB
        label = self.video_labels[video_idx]

        if self.transform is not None:
            frame = self.transform(frame)
        else:
            frame = torch.from_numpy(frame).permute(2, 0, 1).float() / 255.0

        return frame, label

    def get_class_weights(self) -> torch.Tensor:
        """Compute inverse-frequency class weights for handling class imbalance.

        Uses sklearn's compute_class_weight with 'balanced' strategy.

        Returns:
            Tensor of shape (num_classes,) with per-class weights.
        """
        all_labels = np.array(self.video_labels)
        unique_classes = np.arange(len(self.class_names))
        weights = compute_class_weight(
            class_weight="balanced",
            classes=unique_classes,
            y=all_labels,
        )
        return torch.FloatTensor(weights)


class RWF2000Dataset(Dataset):
    """RWF-2000 dataset for binary fight/non-fight classification.

    Expected folder structure:
        data/RWF-2000/
        ├── train/
        │   ├── Fight/
        │   │   └── *.avi
        │   └── NonFight/
        │       └── *.avi
        └── val/
            ├── Fight/
            │   └── *.avi
            └── NonFight/
                └── *.avi

    The RWF-2000 dataset comes pre-split into train and val folders.
    The 'test' split uses the val folder. If a custom split is needed,
    the train folder is further split into train/val using config ratios.
    """

    VIDEO_EXTENSIONS = {".mp4", ".avi", ".mkv", ".mov", ".wmv"}

    def __init__(
        self,
        root_dir: str,
        split: str,
        transform: Optional[Callable] = None,
        config: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize RWF-2000 dataset.

        Args:
            root_dir: Path to the RWF-2000 data directory.
            split: One of 'train', 'val', or 'test'.
            transform: Optional transform to apply to each frame.
            config: Configuration dictionary with dataset parameters.

        Raises:
            FileNotFoundError: If root_dir does not exist.
            ValueError: If split is not one of 'train', 'val', 'test'.
        """
        if not os.path.isdir(root_dir):
            raise FileNotFoundError(
                f"Dataset root directory not found: {root_dir}\n"
                f"Please download the RWF-2000 dataset and place it at: {root_dir}\n"
                f"Download: https://www.kaggle.com/datasets/vulamnguyen/rwf2000"
            )

        if split not in ("train", "val", "test"):
            raise ValueError(f"split must be 'train', 'val', or 'test', got '{split}'")

        self.root_dir = root_dir
        self.split = split
        self.transform = transform
        self.config = config or {}

        self.class_names: List[str] = self.config.get("class_names", ["NonFight", "Fight"])
        self.class_to_idx = {name: i for i, name in enumerate(self.class_names)}
        self.frames_per_video = self.config.get("frames_per_video", 30)
        self.img_size = self.config.get("img_size", 224)
        self.seed = self.config.get("seed", 42)

        # RWF-2000 has pre-defined train/val splits
        if split == "test":
            # Use the provided val folder as the test set
            data_dir = os.path.join(root_dir, "val")
        elif split in ("train", "val"):
            # Split the train folder further into train/val
            data_dir = os.path.join(root_dir, "train")
        else:
            data_dir = os.path.join(root_dir, split)

        if not os.path.isdir(data_dir):
            raise FileNotFoundError(f"Data directory not found: {data_dir}")

        # Discover videos in the chosen directory
        all_video_paths: List[str] = []
        all_labels: List[int] = []

        for class_name in self.class_names:
            class_dir = os.path.join(data_dir, class_name)
            if not os.path.isdir(class_dir):
                print(f"[WARNING] Class directory not found: {class_dir}")
                continue

            for fname in sorted(os.listdir(class_dir)):
                ext = os.path.splitext(fname)[1].lower()
                if ext in self.VIDEO_EXTENSIONS:
                    all_video_paths.append(os.path.join(class_dir, fname))
                    all_labels.append(self.class_to_idx[class_name])

        if not all_video_paths:
            raise FileNotFoundError(
                f"No video files found in {data_dir}. "
                f"Expected subdirectories: {self.class_names}"
            )

        # For train/val, further split the training data
        if split in ("train", "val"):
            rng = random.Random(self.seed)
            combined = list(zip(all_video_paths, all_labels))
            rng.shuffle(combined)

            # Use 85% of train for actual training, 15% for validation
            # (matches roughly 70/15 of total since test is separate)
            n_total = len(combined)
            n_train = int(n_total * 0.85)

            if split == "train":
                selected = combined[:n_train]
            else:  # val
                selected = combined[n_train:]

            self.video_paths = [s[0] for s in selected]
            self.video_labels = [s[1] for s in selected]
        else:
            self.video_paths = all_video_paths
            self.video_labels = all_labels

        # Pre-expand video-level to frame-level index
        self.frame_index: List[Tuple[int, int]] = []
        for vid_idx in range(len(self.video_paths)):
            for frame_idx in range(self.frames_per_video):
                self.frame_index.append((vid_idx, frame_idx))

        # Lazy frame cache
        self._frame_cache: Dict[int, List[np.ndarray]] = {}

        print(
            f"[INFO] RWF-2000 {split} set: {len(self.video_paths)} videos, "
            f"{len(self.frame_index)} frames"
        )

    def _load_video_frames(self, video_idx: int) -> List[np.ndarray]:
        """Load and cache frames from a video.

        Args:
            video_idx: Index into self.video_paths.

        Returns:
            List of RGB frames as numpy arrays.
        """
        if video_idx not in self._frame_cache:
            try:
                frames = _extract_frames_from_video(
                    self.video_paths[video_idx],
                    self.frames_per_video,
                    self.img_size,
                )
            except RuntimeError as e:
                print(f"[WARNING] {e} — returning blank frames")
                frames = [
                    np.zeros((self.img_size, self.img_size, 3), dtype=np.uint8)
                    for _ in range(self.frames_per_video)
                ]
            self._frame_cache[video_idx] = frames
        return self._frame_cache[video_idx]

    def __len__(self) -> int:
        """Return total number of frames across all videos."""
        return len(self.frame_index)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int]:
        """Get a single frame and its label.

        Args:
            idx: Index into the frame-level dataset.

        Returns:
            Tuple of (frame_tensor, label_int).
        """
        video_idx, frame_idx = self.frame_index[idx]
        frames = self._load_video_frames(video_idx)
        frame = frames[frame_idx]
        label = self.video_labels[video_idx]

        if self.transform is not None:
            frame = self.transform(frame)
        else:
            frame = torch.from_numpy(frame).permute(2, 0, 1).float() / 255.0

        return frame, label

    def get_class_weights(self) -> torch.Tensor:
        """Compute inverse-frequency class weights for handling class imbalance.

        Returns:
            Tensor of shape (num_classes,) with per-class weights.
        """
        all_labels = np.array(self.video_labels)
        unique_classes = np.arange(len(self.class_names))
        weights = compute_class_weight(
            class_weight="balanced",
            classes=unique_classes,
            y=all_labels,
        )
        return torch.FloatTensor(weights)


def get_dataloader(
    dataset: Dataset,
    batch_size: int,
    shuffle: bool,
    num_workers: int = 4,
) -> DataLoader:
    """Create a DataLoader with optimized settings.

    Args:
        dataset: A PyTorch Dataset instance.
        batch_size: Number of samples per batch.
        shuffle: Whether to shuffle the data each epoch.
        num_workers: Number of data loading worker processes.

    Returns:
        Configured DataLoader instance.
    """
    return DataLoader(
        dataset=dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True,
        drop_last=False,
    )

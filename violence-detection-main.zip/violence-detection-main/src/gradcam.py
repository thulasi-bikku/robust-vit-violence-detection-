"""
Grad-CAM visualization for the Vision Transformer violence classifier.

Implements VitGradCAM using the pytorch-grad-cam library to produce
heatmap overlays showing which image regions the model attends to
when making violence classification decisions. Visual style matches
Figure 5 of the paper.
"""

import os
from typing import Any, Dict, List, Optional, Tuple

import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image
from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget


def _reshape_transform(tensor: torch.Tensor) -> torch.Tensor:
    """Reshape ViT output tensor for Grad-CAM compatibility.

    ViT outputs tokens of shape (B, num_patches+1, dim). We discard the
    [CLS] token and reshape the patch tokens to a spatial grid suitable
    for CAM overlay generation.

    Args:
        tensor: ViT layer output of shape (B, num_tokens, dim).

    Returns:
        Reshaped tensor of shape (B, dim, H, W) where H=W=sqrt(num_patches).
    """
    # tensor shape: (B, num_patches + 1, dim)
    result = tensor[:, 1:, :]  # Remove [CLS] token → (B, num_patches, dim)
    num_patches = result.shape[1]
    h = w = int(num_patches ** 0.5)
    result = result.reshape(result.shape[0], h, w, result.shape[2])
    result = result.permute(0, 3, 1, 2)  # (B, dim, H, W)
    return result


class VitGradCAM:
    """Grad-CAM visualization for Vision Transformer models.

    Uses the pytorch-grad-cam library with a reshape transform to
    adapt ViT's token-based output to spatial feature maps compatible
    with standard Grad-CAM computation.

    Attributes:
        model: The ViT violence classifier model.
        cam: GradCAM instance from pytorch-grad-cam.
        device: Compute device for inference.
    """

    def __init__(
        self,
        model: nn.Module,
        target_layer: Optional[nn.Module] = None,
        device: Optional[torch.device] = None,
    ) -> None:
        """Initialize VitGradCAM.

        Args:
            model: Trained ViTViolenceClassifier model.
            target_layer: Specific layer to compute Grad-CAM for. If None,
                          defaults to the last transformer block's
                          layer normalization (norm1), which is standard
                          practice for ViT Grad-CAM.
            device: Compute device. If None, inferred from model parameters.
        """
        self.model = model
        self.model.eval()

        if device is None:
            self.device = next(model.parameters()).device
        else:
            self.device = device

        # Default target layer: the LayerNorm after the last transformer block
        if target_layer is None:
            target_layer = model.vit.blocks[-1].norm1

        self.target_layers = [target_layer]

        self.cam = GradCAM(
            model=model,
            target_layers=self.target_layers,
            reshape_transform=_reshape_transform,
        )

        print(
            f"[INFO] VitGradCAM initialized with target layer: "
            f"{target_layer.__class__.__name__}"
        )

    def generate_heatmap(
        self,
        image_tensor: torch.Tensor,
        target_class: Optional[int] = None,
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Generate a Grad-CAM heatmap overlaid on the original image.

        Args:
            image_tensor: Preprocessed image tensor of shape (1, 3, H, W)
                          or (3, H, W). Values should be normalized.
            target_class: Target class index for Grad-CAM. If None,
                          uses the predicted class.

        Returns:
            Tuple of:
            - heatmap_overlay: RGB image (H, W, 3) with CAM overlay, float32 [0,1].
            - raw_cam: Raw CAM activation map (H, W), float32 [0,1].
        """
        if image_tensor.dim() == 3:
            image_tensor = image_tensor.unsqueeze(0)

        image_tensor = image_tensor.to(self.device)

        # Determine target class
        if target_class is not None:
            targets = [ClassifierOutputTarget(target_class)]
        else:
            targets = None  # Uses the predicted class

        # Generate CAM
        grayscale_cam = self.cam(
            input_tensor=image_tensor,
            targets=targets,
        )

        raw_cam = grayscale_cam[0, :]  # (H, W)

        # Denormalize image for overlay (reverse mean=0.5, std=0.5)
        img_np = image_tensor[0].cpu().numpy().transpose(1, 2, 0)  # (H, W, 3)
        img_np = img_np * 0.5 + 0.5  # Denormalize
        img_np = np.clip(img_np, 0, 1).astype(np.float32)

        # Create overlay
        heatmap_overlay = show_cam_on_image(img_np, raw_cam, use_rgb=True)
        heatmap_overlay = heatmap_overlay.astype(np.float32) / 255.0

        return heatmap_overlay, raw_cam

    def visualize_batch(
        self,
        images: torch.Tensor,
        labels: torch.Tensor,
        predictions: torch.Tensor,
        save_path: str,
        class_names: Optional[List[str]] = None,
        max_images: int = 16,
    ) -> None:
        """Visualize a batch of images with Grad-CAM overlays.

        Creates a grid showing original images alongside their Grad-CAM
        heatmaps, with true and predicted labels annotated. Correct
        predictions are highlighted in green, incorrect in red.

        Args:
            images: Batch of preprocessed image tensors (B, 3, H, W).
            labels: Ground truth labels (B,).
            predictions: Model predictions (B,).
            save_path: Filesystem path to save the visualization.
            class_names: Optional list of class name strings.
            max_images: Maximum number of images to display in the grid.
        """
        num_images = min(len(images), max_images)
        cols = 4
        rows = (num_images + cols - 1) // cols

        fig, axes = plt.subplots(rows, cols * 2, figsize=(cols * 6, rows * 3.5))

        if rows == 1:
            axes = axes.reshape(1, -1)

        for idx in range(num_images):
            row = idx // cols
            col = idx % cols

            image_tensor = images[idx]
            true_label = labels[idx].item() if isinstance(labels[idx], torch.Tensor) else labels[idx]
            pred_label = predictions[idx].item() if isinstance(predictions[idx], torch.Tensor) else predictions[idx]

            # Denormalize original image
            img_np = image_tensor.cpu().numpy().transpose(1, 2, 0)
            img_np = img_np * 0.5 + 0.5
            img_np = np.clip(img_np, 0, 1)

            # Generate heatmap
            heatmap_overlay, _ = self.generate_heatmap(
                image_tensor, target_class=pred_label
            )

            is_correct = true_label == pred_label
            border_color = "green" if is_correct else "red"

            true_name = class_names[true_label] if class_names and true_label < len(class_names) else str(true_label)
            pred_name = class_names[pred_label] if class_names and pred_label < len(class_names) else str(pred_label)

            # Original image
            ax_orig = axes[row, col * 2]
            ax_orig.imshow(img_np)
            ax_orig.set_title(f"True: {true_name}", fontsize=9, fontweight="bold")
            ax_orig.axis("off")
            for spine in ax_orig.spines.values():
                spine.set_edgecolor(border_color)
                spine.set_linewidth(3)
                spine.set_visible(True)

            # Grad-CAM overlay
            ax_cam = axes[row, col * 2 + 1]
            ax_cam.imshow(heatmap_overlay)
            ax_cam.set_title(
                f"Pred: {pred_name} {'✓' if is_correct else '✗'}",
                fontsize=9,
                fontweight="bold",
                color="darkgreen" if is_correct else "darkred",
            )
            ax_cam.axis("off")
            for spine in ax_cam.spines.values():
                spine.set_edgecolor(border_color)
                spine.set_linewidth(3)
                spine.set_visible(True)

        # Hide unused axes
        for idx in range(num_images, rows * cols):
            row = idx // cols
            col = idx % cols
            axes[row, col * 2].axis("off")
            axes[row, col * 2 + 1].axis("off")

        fig.suptitle(
            "Grad-CAM Visualizations — Violence Detection ViT",
            fontsize=16,
            fontweight="bold",
            y=1.02,
        )

        plt.tight_layout()
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"[INFO] Grad-CAM visualization saved to: {save_path}")

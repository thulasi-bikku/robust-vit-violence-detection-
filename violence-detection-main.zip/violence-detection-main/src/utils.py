"""
Utility functions for the Violence Detection ViT framework.

Provides helper functions for reproducibility, device management,
model inspection, visualization, and configuration loading.
"""

import os
import random
import time
from pathlib import Path
from typing import Any, Dict, Optional

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch
import yaml


def set_seed(seed: int = 42) -> None:
    """Set random seeds for full reproducibility across all libraries.

    Args:
        seed: Integer seed value. Default is 42 as specified in the paper.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    os.environ["PYTHONHASHSEED"] = str(seed)


def get_device() -> torch.device:
    """Detect and return the best available compute device.

    Returns:
        torch.device: CUDA if available, then MPS (Apple Silicon), else CPU.
    """
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"[INFO] Using CUDA device: {torch.cuda.get_device_name(0)}")
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        device = torch.device("mps")
        print("[INFO] Using Apple MPS device")
    else:
        device = torch.device("cpu")
        print("[INFO] Using CPU device")
    return device


def count_parameters(model: torch.nn.Module) -> int:
    """Print and return the number of trainable parameters in a model.

    Args:
        model: PyTorch model to inspect.

    Returns:
        Total number of trainable parameters.
    """
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"[INFO] Model Parameters:")
    print(f"       Trainable : {trainable:,}")
    print(f"       Total     : {total:,}")
    print(f"       Frozen    : {total - trainable:,}")
    return trainable


def plot_training_history(history: Dict[str, list], save_path: str) -> None:
    """Plot training and validation loss/F1 curves across epochs.

    Generates a two-panel figure: left panel shows loss curves, right panel
    shows F1-score curves, both for training and validation sets.

    Args:
        history: Dictionary with keys 'train_loss', 'val_loss',
                 'train_f1', 'val_f1' each mapping to a list of floats.
        save_path: Filesystem path to save the generated figure.
    """
    epochs = range(1, len(history["train_loss"]) + 1)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # --- Loss Curves ---
    axes[0].plot(epochs, history["train_loss"], "b-o", label="Train Loss", markersize=3)
    axes[0].plot(epochs, history["val_loss"], "r-o", label="Val Loss", markersize=3)
    axes[0].set_xlabel("Epoch", fontsize=12)
    axes[0].set_ylabel("Loss", fontsize=12)
    axes[0].set_title("Training & Validation Loss", fontsize=14, fontweight="bold")
    axes[0].legend(fontsize=11)
    axes[0].grid(True, alpha=0.3)

    # --- F1-Score Curves ---
    axes[1].plot(epochs, history["train_f1"], "b-o", label="Train F1", markersize=3)
    axes[1].plot(epochs, history["val_f1"], "r-o", label="Val F1", markersize=3)
    axes[1].set_xlabel("Epoch", fontsize=12)
    axes[1].set_ylabel("F1-Score", fontsize=12)
    axes[1].set_title("Training & Validation F1-Score", fontsize=14, fontweight="bold")
    axes[1].legend(fontsize=11)
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"[INFO] Training history plot saved to: {save_path}")


def save_metrics_to_csv(metrics: Dict[str, Any], path: str) -> None:
    """Save evaluation metrics dictionary to a CSV file.

    Args:
        metrics: Dictionary of metric names to values.
        path: Filesystem path for the output CSV.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df = pd.DataFrame([metrics])
    df.to_csv(path, index=False)
    print(f"[INFO] Metrics saved to: {path}")


def format_time(seconds: float) -> str:
    """Convert seconds to a human-readable time string.

    Args:
        seconds: Duration in seconds.

    Returns:
        Formatted string like '1h 23m 45s' or '5m 12s'.
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)

    if hours > 0:
        return f"{hours}h {minutes}m {secs}s"
    elif minutes > 0:
        return f"{minutes}m {secs}s"
    else:
        return f"{secs}s"


def create_output_dirs(config: Dict[str, Any]) -> None:
    """Create all output directories specified in the config.

    Creates checkpoint and log directories, plus a plots subdirectory.

    Args:
        config: Configuration dictionary with 'checkpoint_dir' and 'log_dir' keys.
    """
    dirs_to_create = [
        config["checkpoint_dir"],
        config["log_dir"],
        os.path.join(config["log_dir"], "plots"),
    ]
    for d in dirs_to_create:
        os.makedirs(d, exist_ok=True)
        print(f"[INFO] Directory ready: {d}")


def load_config(path: str) -> Dict[str, Any]:
    """Load and validate a YAML configuration file.

    Args:
        path: Path to the YAML config file.

    Returns:
        Configuration dictionary with all parameters.

    Raises:
        FileNotFoundError: If the config file does not exist.
        ValueError: If required configuration keys are missing.
    """
    if not os.path.exists(path):
        raise FileNotFoundError(f"Configuration file not found: {path}")

    with open(path, "r") as f:
        config = yaml.safe_load(f)

    required_keys = [
        "dataset_name",
        "data_root",
        "num_classes",
        "class_names",
        "img_size",
        "batch_size",
        "num_epochs",
        "learning_rate",
        "early_stopping_patience",
        "train_split",
        "val_split",
        "test_split",
        "frames_per_video",
        "seed",
        "checkpoint_dir",
        "log_dir",
    ]
    missing = [k for k in required_keys if k not in config]
    if missing:
        raise ValueError(f"Missing required config keys: {missing}")

    # Validate split ratios sum to 1.0
    split_sum = config["train_split"] + config["val_split"] + config["test_split"]
    if abs(split_sum - 1.0) > 1e-6:
        raise ValueError(
            f"Data split ratios must sum to 1.0, got {split_sum:.4f} "
            f"({config['train_split']} + {config['val_split']} + {config['test_split']})"
        )

    # Validate num_classes matches class_names length
    if len(config["class_names"]) != config["num_classes"]:
        raise ValueError(
            f"num_classes ({config['num_classes']}) does not match "
            f"length of class_names ({len(config['class_names'])})"
        )

    # Set defaults for optional keys
    config.setdefault("model_name", "vit_base_patch16_224")
    config.setdefault("weight_decay", 0.01)
    config.setdefault("num_workers", 4)
    config.setdefault("patch_size", 16)

    print(f"[INFO] Loaded config for dataset: {config['dataset_name']}")
    print(f"       Classes   : {config['num_classes']}")
    print(f"       Img size  : {config['img_size']}x{config['img_size']}")
    print(f"       Batch size: {config['batch_size']}")
    print(f"       Epochs    : {config['num_epochs']}")
    print(f"       LR        : {config['learning_rate']}")

    return config

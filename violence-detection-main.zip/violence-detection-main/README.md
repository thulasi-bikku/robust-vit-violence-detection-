# Violence Detection using Vision Transformer (ViT)

> **Paper**: *A Generalizable Vision Transformer Framework for Low-False-Alarm Violence Detection*

A complete PyTorch implementation of a Vision Transformer (ViT) based violence detection system. This framework classifies video frames into violence categories using a pretrained `vit_base_patch16_224` backbone from the [timm](https://github.com/huggingface/pytorch-image-models) library, fine-tuned on surveillance video datasets.

---

## ✨ Key Features

- **ViT-Base/16 backbone** with pretrained ImageNet weights via `timm`
- **Two dataset pipelines**: UCF-Crime (14-class) and RWF-2000 (binary)
- **Class imbalance handling** via weighted Cross-Entropy loss
- **Comprehensive augmentation pipeline** (rotation, flip, crop, blur, color jitter)
- **Early stopping** based on validation loss with configurable patience
- **Full evaluation suite**: Accuracy, Precision, Recall, F1, ROC AUC
- **Grad-CAM visualization** for model interpretability
- **TensorBoard logging** for real-time training monitoring
- **Reproducible experiments** with seed control across all libraries

---

## 📁 Project Structure

```

├── data/                          # Datasets (user-provided)
├── src/
│   ├── __init__.py
│   ├── dataset.py                 # UCF-Crime and RWF-2000 dataset classes
│   ├── model.py                   # ViT classifier with attention extraction
│   ├── transforms.py              # Augmentation pipelines (Table 2)
│   ├── train.py                   # Trainer with early stopping & TensorBoard
│   ├── evaluate.py                # Full evaluation with plots
│   ├── gradcam.py                 # Grad-CAM visualization for ViT
│   └── utils.py                   # Helpers (seed, device, config, plots)
├── configs/
│   ├── ucf_crime.yaml             # UCF-Crime configuration
│   └── rwf2000.yaml               # RWF-2000 configuration
├── scripts/
│   ├── train_ucf.sh               # Shell script: train on UCF-Crime
│   ├── train_rwf.sh               # Shell script: train on RWF-2000
│   └── evaluate.sh                # Shell script: evaluate a checkpoint
├── notebooks/
│   └── visualization.ipynb        # Interactive visualization notebook
├── outputs/                       # Checkpoints, logs, plots (auto-created)
├── requirements.txt               # Pinned dependencies
├── main.py                        # CLI entry point
└── README.md                      # This file
```

---

## 🛠️ Installation

### Prerequisites

- Python 3.8+
- CUDA-capable GPU (recommended) or Apple MPS
- pip package manager

### Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/violence-detection-vit.git
cd violence-detection-vit

# Install dependencies
pip install -r requirements.txt
```

---

## 📦 Dataset Setup

### UCF-Crime Dataset

**Download**: [https://www.crcv.ucf.edu/projects/real-world/](https://www.crcv.ucf.edu/projects/real-world/)

Organize the data into the following structure:

```
data/UCF_Crime/
├── Normal/
│   ├── Normal001.mp4
│   ├── Normal002.mp4
│   └── ...
├── Abuse/
│   ├── Abuse001.mp4
│   └── ...
├── Arrest/
├── Assault/
├── Burglary/
├── Explosion/
├── Fighting/
├── RoadAccidents/
├── Robbery/
├── Shooting/
├── Shoplifting/
├── Stealing/
├── Vandalism/
└── Arson/
```

### RWF-2000 Dataset

**Download**: [https://www.kaggle.com/datasets/vulamnguyen/rwf2000](https://www.kaggle.com/datasets/vulamnguyen/rwf2000)

Organize the data into the following structure:

```
data/RWF-2000/
├── train/
│   ├── Fight/
│   │   ├── fi001.avi
│   │   └── ...
│   └── NonFight/
│       ├── no001.avi
│       └── ...
└── val/
    ├── Fight/
    │   ├── fi001.avi
    │   └── ...
    └── NonFight/
        ├── no001.avi
        └── ...
```

---

## 🚀 Usage

### Training

```bash
# Train on UCF-Crime (14-class)
python main.py --mode train --config configs/ucf_crime.yaml

# Train on RWF-2000 (binary)
python main.py --mode train --config configs/rwf2000.yaml

# Override data root
python main.py --mode train --config configs/ucf_crime.yaml --data_root /path/to/data

# Override device
python main.py --mode train --config configs/ucf_crime.yaml --device cuda
```

Or use the provided shell scripts:

```bash
bash scripts/train_ucf.sh
bash scripts/train_rwf.sh
```

### Evaluation

```bash
# Evaluate UCF-Crime
python main.py --mode evaluate \
    --config configs/ucf_crime.yaml \
    --checkpoint outputs/checkpoints/ucf/best_model.pth

# Evaluate RWF-2000
python main.py --mode evaluate \
    --config configs/rwf2000.yaml \
    --checkpoint outputs/checkpoints/rwf/best_model.pth
```

### Grad-CAM Visualization

```bash
python main.py --mode visualize \
    --config configs/ucf_crime.yaml \
    --checkpoint outputs/checkpoints/ucf/best_model.pth
```

### TensorBoard

```bash
tensorboard --logdir outputs/logs/
```

---

## 📊 Expected Results

Results matching **Table 3** of the paper:

### UCF-Crime Dataset (14-class)

| Metric     | Score  |
|------------|--------|
| Accuracy   | 92.50% |
| Precision  | 0.91   |
| Recall     | 0.87   |
| F1-Score   | 0.89   |

### RWF-2000 Dataset (Binary)

| Metric     | Score  |
|------------|--------|
| Accuracy   | 98.61% |
| Precision  | 0.99   |
| Recall     | 0.99   |
| F1-Score   | 0.99   |

---

## ⚙️ Model Architecture

```
Input Image (224×224×3)
    │
    ▼
Patch Embedding (16×16 patches → 196 tokens + 1 [CLS])
    │
    ▼
12× Transformer Encoder Blocks
    │  ├── Multi-Head Self-Attention (12 heads)
    │  ├── Layer Normalization
    │  └── MLP (Feed-Forward)
    │
    ▼
[CLS] Token (768-dim)
    │
    ▼
Classification Head: Linear(768, num_classes)
    │
    ▼
Logits → CrossEntropyLoss
```

### Key Hyperparameters

| Parameter         | Value                    |
|-------------------|--------------------------|
| Backbone          | vit_base_patch16_224     |
| Input size        | 224 × 224                |
| Patch size        | 16 × 16                 |
| [CLS] dimension   | 768                      |
| Optimizer         | AdamW                    |
| Learning rate     | 1 × 10⁻⁵                |
| Batch size        | 64                       |
| Early stopping    | patience = 10            |
| Data split        | 70 / 15 / 15 (video-level) |
| Frames per video  | 30 (uniform sampling)   |
| Seed              | 42                       |

---

## 📝 Augmentation Pipeline (Table 2)

| Augmentation          | Parameters                     |
|-----------------------|--------------------------------|
| Random Rotation       | degrees = (−10, 10)            |
| Random Horizontal Flip| p = 0.5                        |
| Random Resized Crop   | scale = (0.8, 1.0), size = 224 |
| Gaussian Blur         | σ = (0.1, 2.0)                 |
| Color Jitter          | brightness = 0.2, contrast = 0.2 |
| Normalize             | μ = [0.5, 0.5, 0.5], σ = [0.5, 0.5, 0.5] |

---

## 📂 Output Structure

After training, the following outputs are generated:

```
outputs/
├── checkpoints/
│   ├── ucf/
│   │   └── best_model.pth          # Best model (by val F1)
│   └── rwf/
│       └── best_model.pth
└── logs/
    ├── ucf/
    │   ├── events.out.tfevents.*    # TensorBoard logs
    │   └── plots/
    │       ├── training_history.png
    │       ├── confusion_matrix.png
    │       ├── roc_curves.png
    │       ├── metrics_comparison.png
    │       ├── gradcam_visualization.png
    │       └── test_metrics.csv
    └── rwf/
        └── ...
```

---

## 🔬 Citation

If you use this code in your research, please cite the original paper:

```bibtex
@article{violence_detection_vit,
  title={A Generalizable Vision Transformer Framework for Low-False-Alarm Violence Detection},
  year={2024}
}
```

---

## 📄 License

This project is for research and educational purposes. Please refer to the original dataset licenses for usage terms.
